"use client"

export { ThemeProvider } from "next-themes"